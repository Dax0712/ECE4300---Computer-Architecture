`timescale 1ns / 1ps

module signExtTB();

    // instantiate the internal signals for the testbench.
    reg [15:0] imm; // we want to assign input values.
    wire [31:0] ext; // we want to observe the output values.

    signExtend Dut(
        .extended(extended),
        .immediate(immediate)
    )






endmodule